import {
  Resolver,
  Query,
  Mutation,
  Args,
  Int,
  Subscription,
} from '@nestjs/graphql';
import { AssuranceService } from './assurance.service';
import { AssuranceResource } from './dto/assurance.resource';
import { CreateAssuranceInput } from './dto/create-assurance.input';
import { UpdateAssuranceInput } from './dto/update-assurance.input';
import { Inject } from '@nestjs/common';
import { PubSub } from 'graphql-subscriptions';

// Nom de l'event publié dans le PubSub — même valeur utilisée partout
const ASSURANCE_UPDATED_EVENT = 'assuranceUpdated';

/**
 * Resolver GraphQL pour les assurances
 */
@Resolver(() => AssuranceResource)
export class AssuranceResolver {
  @Inject('PUB_SUB')
  pubSub: PubSub;

  constructor(private readonly assuranceService: AssuranceService) {}

  /**
   * Mutation : Créer une nouvelle assurance
   * Publie un event "create" après création réussie
   */
  @Mutation(() => AssuranceResource, {
    name: 'createAssurance',
    description: 'Créer une nouvelle assurance avec ses règlements',
  })
  async createAssurance(
    @Args('input', { type: () => CreateAssuranceInput })
    input: CreateAssuranceInput,
  ): Promise<AssuranceResource> {
    const result = await this.assuranceService.createAssurance(input);

    // Publie l'event — tous les abonnés recevront cet objet
    await this.pubSub.publish(ASSURANCE_UPDATED_EVENT, {
      assuranceUpdated: result,
      // Le champ "action" permet au frontend de savoir ce qui s'est passé
      action: 'create',
    });

    return result;
  }

  /**
   * Query : Récupérer toutes les assurances actives
   */
  @Query(() => [AssuranceResource], {
    name: 'assurances',
    description: 'Récupérer toutes les assurances actives',
  })
  async findAllAssurances(): Promise<AssuranceResource[]> {
    return this.assuranceService.findAllAssurances();
  }

  /**
   * Query : Récupérer une assurance par son ID
   */
  @Query(() => AssuranceResource, {
    name: 'assurance',
    description: 'Récupérer une assurance par son ID',
    nullable: true,
  })
  async findAssuranceById(
    @Args('id', { type: () => String }) id: string,
  ): Promise<AssuranceResource> {
    return this.assuranceService.findAssuranceById(id);
  }

  /**
   * Query : Récupérer les assurances d'un véhicule
   */
  @Query(() => [AssuranceResource], {
    name: 'assurancesByVehicule',
    description: "Récupérer toutes les assurances d'un véhicule spécifique",
  })
  async findAssurancesByVehicule(
    @Args('vehiculeId', { type: () => String }) vehiculeId: string,
  ): Promise<AssuranceResource[]> {
    return this.assuranceService.findAssurancesByVehicule(vehiculeId);
  }

  /**
   * Query : Récupérer les assurances qui expirent bientôt
   */
  @Query(() => [AssuranceResource], {
    name: 'assurancesExpiringSoon',
    description: 'Récupérer les assurances qui expirent dans N jours',
  })
  async findAssurancesExpiringSoon(
    @Args('daysBeforeExpiry', { type: () => Int, defaultValue: 30 })
    daysBeforeExpiry: number,
  ): Promise<AssuranceResource[]> {
    return this.assuranceService.findAssurancesExpiringSoon(daysBeforeExpiry);
  }

  /**
   * Mutation : Mettre à jour une assurance
   *  Publie un event "update" après mise à jour réussie
   */
  @Mutation(() => AssuranceResource, {
    name: 'updateAssurance',
    description: "Mettre à jour les informations d'une assurance",
  })
  async updateAssurance(
    @Args('input', { type: () => UpdateAssuranceInput })
    input: UpdateAssuranceInput,
  ): Promise<AssuranceResource> {
    const result = await this.assuranceService.updateAssurance(input);

    await this.pubSub.publish(ASSURANCE_UPDATED_EVENT, {
      assuranceUpdated: result,
      action: 'update',
    });

    return result;
  }

  /**
   * Mutation : Supprimer une assurance (soft delete)
   *  Publie un event "delete" avec l'ID supprimé
   */
  @Mutation(() => Boolean, {
    name: 'deleteAssurance',
    description: 'Supprimer une assurance (désactivation)',
  })
  async deleteAssurance(
    @Args('id', { type: () => String }) id: string,
  ): Promise<boolean> {
    const success = await this.assuranceService.deleteAssurance(id);

    if (success) {
      // Pour delete on ne peut pas envoyer l'objet complet (il est désactivé)
      // On envoie un objet minimal avec juste l'id et estActif = false
      await this.pubSub.publish(ASSURANCE_UPDATED_EVENT, {
        assuranceUpdated: { id, estActif: false },
        action: 'delete',
      });
    }

    return success;
  }

  @Subscription(() => AssuranceResource, {
    name: 'assuranceUpdated',
    filter: (payload, variables) => {
      // payload = { assuranceUpdated: AssuranceResource, action: string }
      // variables = { ids?: string[] } — arguments envoyés par le frontend

      // Si pas de filtre d'IDs → envoyer l'event à tout le monde
      if (!variables.ids || variables.ids.length === 0) {
        return true;
      }

      // Sinon, n'envoyer que si l'id de l'assurance est dans la liste demandée
      return variables.ids.includes(payload.assuranceUpdated.id);
    },
    nullable: true,
  })
  assuranceUpdated(
    @Args({ name: 'ids', type: () => [String], nullable: true }) ids?: string[],
  ) {
    // Cette méthode ne fait QUE s'abonner au canal PubSub
    // Elle est appelée une seule fois lors de l'ouverture de la subscription WebSocket
    return this.pubSub.asyncIterableIterator(ASSURANCE_UPDATED_EVENT);
  }
}
